Readme file for WISDM's activity prediction dataset v1.0
Updated: Nov. 18, 2012

This data has been released by the Wireless Sensor Data Mining
(WISDM) Lab. <http://www.cis.fordham.edu/wisdm/>

The data in this file corrispond with the data used in the
following paper:

Jennifer R. Kwapisz, Gary M. Weiss and Samuel A. Moore (2010). 
Activity Recognition using Cell Phone Accelerometers, 
Proceedings of the Fourth International Workshop on Knowledge 
Discovery from Sensor Data (at KDD-10), Washington DC. 
<http://www.cis.fordham.edu/wisdm/public_files/sensorKDD-2010.pdf>

When using this dataset, we request that you cite this paper.

When sharing or redistributing this dataset, we request that
this readme.txt file is always included. 

Files:
readme.txt
about_raw.txt
about_transformed.txt
raw.txt
transformed.arff

Changelog (v1.0):
* user names masked with ID numbers 1-36
